// Lógica do app: usa localStorage para dados
const SERVICES = [
  {id:'musculacao', name:'Musculação', price:40, icon:'fa-dumbbell'},
  {id:'personal', name:'Personal Trainer', price:120, icon:'fa-user-tie'},
  {id:'yoga', name:'Aula de Yoga', price:30, icon:'fa-person-running'},
  {id:'avaliacao', name:'Avaliação Física', price:60, icon:'fa-heart-pulse'}
]
const COMBOS = [
  {id:'personal_avaliacao', name:'Personal + Avaliação', items:['personal','avaliacao'], price:160},
  {id:'muscu_yoga', name:'Musculação + Aula de Yoga', items:['musculacao','yoga'], price:60}
]

// storage helpers
const DB = {
  get(k){try{return JSON.parse(localStorage.getItem(k))||null}catch(e){return null}},
  set(k,v){localStorage.setItem(k,JSON.stringify(v))}
}

function el(id){return document.getElementById(id)}

function renderServices(){
  const container = el('servicesList')
  SERVICES.forEach(s=>{
    const d = document.createElement('div')
    d.className='service'
    d.innerHTML = `<i class="fa ${s.icon}"></i><strong>${s.name}</strong><span class="small">R$ ${s.price}</span>`
    d.onclick = ()=>openBooking({serviceId:s.id})
    container.appendChild(d)
  })
}

function renderCombos(){
  const c = el('combosList')
  COMBOS.forEach(cb=>{
    const d=document.createElement('div');d.className='combo';d.innerHTML=`<strong>${cb.name}</strong><div class="small">R$ ${cb.price}</div>`
    d.onclick = ()=>openBooking({comboId:cb.id})
    c.appendChild(d)
  })
}

function openModal(html){
  el('modalBody').innerHTML=''
  el('modalBody').appendChild(html)
  el('modal').classList.remove('hidden')
}

function closeModal(){el('modal').classList.add('hidden')}

document.addEventListener('click',e=>{if(e.target.id==='modal' || e.target.id==='modalClose') closeModal()})

function openBooking({serviceId,comboId}={}){
  const wrapper = document.createElement('div')
  const title = document.createElement('h3')
  title.textContent = 'Agendar Serviço'
  wrapper.appendChild(title)

  const select = document.createElement('select')
  select.id='serviceSelect'
  SERVICES.forEach(s=>{
    const o=document.createElement('option');o.value=s.id;o.textContent=`${s.name} - R$ ${s.price}`;select.appendChild(o)
  })
  wrapper.appendChild(select)

  const date = document.createElement('input');date.type='datetime-local';date.id='apptDate';wrapper.appendChild(date)

  const favs = DB.get('favTimes')||[]
  const favWrap = document.createElement('div')
  favWrap.innerHTML='<label>Favoritos</label>'
  favs.forEach(t=>{const b=document.createElement('span');b.className='fav-time';b.textContent=t;b.onclick=()=>{date.value=t};favWrap.appendChild(b)})
  wrapper.appendChild(favWrap)

  const note = document.createElement('textarea');note.placeholder='Observações (opcional)';wrapper.appendChild(note)

  const row = document.createElement('div');row.className='row'
  const bookBtn = document.createElement('button');bookBtn.textContent='Confirmar e Pagar';bookBtn.className='primary'
  bookBtn.onclick = ()=>{createAppointment({serviceId:select.value,date:date.value,note:note.value,comboId})}
  const saveFav = document.createElement('button');saveFav.textContent='Salvar horário';saveFav.onclick=()=>saveFavorite(date.value)
  row.appendChild(bookBtn);row.appendChild(saveFav)
  wrapper.appendChild(row)

  openModal(wrapper)
  if(serviceId) select.value=serviceId
}

function saveFavorite(t){if(!t)return alert('Escolha um horário');const favs=DB.get('favTimes')||[];if(!favs.includes(t))favs.unshift(t);DB.set('favTimes',favs.slice(0,6));alert('Horário salvo como favorito')}

function createAppointment({serviceId,date,note,comboId}){
  if(!date) return alert('Escolha data e hora')
  const appts = DB.get('appointments')||[]
  const id = 'a'+Date.now()
  const item = {id,serviceId,comboId,date,note,status:'confirmado'}
  appts.unshift(item);DB.set('appointments',appts)
  closeModal();renderAppointments();openPayment(item)
}

function renderAppointments(){
  const list = el('appointmentsList');list.innerHTML=''
  const appts = DB.get('appointments')||[]
  if(appts.length===0){list.innerHTML='<div class="small">Nenhum agendamento</div>';return}
  appts.forEach(a=>{
    const div=document.createElement('div');div.className='card'
    const title = a.comboId? COMBOS.find(c=>c.id===a.comboId).name : SERVICES.find(s=>s.id===a.serviceId).name
    div.innerHTML = `<strong>${title}</strong><div class="small">${new Date(a.date).toLocaleString()}</div><div class="small">${a.status}</div>`
    const btns = document.createElement('div');btns.style.marginTop='8px'
    const pay = document.createElement('button');pay.textContent='Pagar agora';pay.onclick=()=>openPayment(a);btns.appendChild(pay)
    const remind = document.createElement('button');remind.textContent='Enviar lembrete';remind.onclick=()=>sendReminder(a);btns.appendChild(remind)
    const done = document.createElement('button');done.textContent='Finalizar';done.onclick=()=>completeAppointment(a.id);btns.appendChild(done)
    const fb = document.createElement('button');fb.textContent='Avaliar';fb.onclick=()=>openFeedback(a);btns.appendChild(fb)
    div.appendChild(btns)
    list.appendChild(div)
  })
}

function openPayment(appt){
  const wrapper = document.createElement('div')
  wrapper.innerHTML = `<h3>Pagamento</h3><p class="small">Use o QR abaixo para pagar rapidamente.</p><div id="qrcode"></div><div class="small">Valor: R$ ${getPrice(appt)}</div>`
  const payNow = document.createElement('button');payNow.textContent='Simular pagamento';payNow.className='primary'
  payNow.onclick = ()=>{markPaid(appt.id);alert('Pagamento registrado (simulado)');closeModal();renderAppointments()}
  wrapper.appendChild(payNow)
  openModal(wrapper)
  // gerar QR code simples com link de pagamento simulado
  setTimeout(()=>{new QRCode(document.getElementById('qrcode'),{text:`https://pag.example.com/pay?ref=${appt.id}&v=${getPrice(appt)}`,width:160,height:160})},100)
}

function getPrice(appt){if(appt.comboId)return COMBOS.find(c=>c.id===appt.comboId).price;return SERVICES.find(s=>s.id===appt.serviceId).price}

function markPaid(id){const appts=DB.get('appointments')||[];const a=appts.find(x=>x.id===id);if(a){a.status='pago';DB.set('appointments',appts)} }

function sendReminder(appt){alert(`Lembrete enviado para o agendamento em ${new Date(appt.date).toLocaleString()} (simulado)`)}

function completeAppointment(id){const appts=DB.get('appointments')||[];const a=appts.find(x=>x.id===id);if(a){a.status='concluido';DB.set('appointments',appts);renderAppointments();alert('Atendimento marcado como concluído')}}

function openFeedback(appt){
  const wrapper=document.createElement('div')
  wrapper.innerHTML=`<h3>Avaliar atendimento</h3><label>Nota (1-5)</label>`
  const nota=document.createElement('input');nota.type='number';nota.min=1;nota.max=5
  const comentario=document.createElement('textarea');comentario.placeholder='Comentário'
  const send=document.createElement('button');send.textContent='Enviar';send.onclick=()=>{saveFeedback(appt.id,nota.value,comentario.value);closeModal();alert('Obrigado pelo feedback!')}
  wrapper.appendChild(nota);wrapper.appendChild(comentario);wrapper.appendChild(send)
  openModal(wrapper)
}

function saveFeedback(apptId,score,comment){const fb=DB.get('feedbacks')||[];fb.unshift({apptId,score,comment,date:new Date().toISOString()});DB.set('feedbacks',fb)}

function initNotifications(){el('notificationsBtn').onclick=()=>{
  const promos = DB.get('promos')||[{title:'10% off na seg. feira'}]
  const wrapper=document.createElement('div');wrapper.innerHTML=`<h3>Notificações</h3>`
  promos.forEach(p=>{const d=document.createElement('div');d.className='card';d.innerHTML=`<strong>${p.title}</strong>`;wrapper.appendChild(d)})
  openModal(wrapper)
}}

function initContact(){el('contactBtn').onclick=()=>{const phone='5511999999999';window.open(`https://wa.me/${phone}?text=Olá,%20gostaria%20de%20informações%20sobre%20agendamento`,'_blank')}}

function initShare(){el('shareBtn').onclick=()=>{
  const data={title:'Barbearia Express',text:'Agende seu corte de forma rápida!',url:location.href}
  if(navigator.share) navigator.share(data).catch(()=>navigator.clipboard.writeText(location.href))
  else navigator.clipboard.writeText(location.href).then(()=>alert('Link copiado'))
}}

function initQuickButtons(){el('quickBook').onclick=()=>openBooking()
  el('promoBtn').onclick=()=>openPromos()
  el('couponsBtn').onclick=()=>openPromos()
}

function openPromos(){const wrapper=document.createElement('div');wrapper.innerHTML=`<h3>Cupons & Promoções</h3><div class="card"><strong>10% OFF para novos clientes</strong></div>`;openModal(wrapper)}

function initProfile(){el('profileBtn').onclick=()=>{
  const prof = DB.get('profile')||{name:'',phone:''}
  const wrapper=document.createElement('div')
  wrapper.innerHTML = `<h3>Meu Perfil</h3>`
  const name = document.createElement('input');name.value=prof.name;name.placeholder='Nome'
  const phone = document.createElement('input');phone.value=prof.phone;phone.placeholder='Telefone'
  const save = document.createElement('button');save.textContent='Salvar';save.onclick=()=>{DB.set('profile',{name:name.value,phone:phone.value});alert('Perfil salvo');closeModal()}
  wrapper.appendChild(name);wrapper.appendChild(phone);wrapper.appendChild(save)
  openModal(wrapper)
}}

function init(){renderServices();renderCombos();renderAppointments();initNotifications();initContact();initShare();initQuickButtons();initProfile()}

init()
