const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const path = require('path')
const ds = require('./server/data-store')

const app = express()
app.use(cors())
app.use(bodyParser.json())

// Servir arquivos estáticos (frontend)
app.use(express.static(path.join(__dirname)))

// API
app.get('/api/services', (req,res)=>{res.json(ds.get('services')||[] )})
app.get('/api/combos', (req,res)=>{res.json(ds.get('combos')||[] )})

app.get('/api/appointments', (req,res)=>{res.json(ds.get('appointments')||[])})

app.post('/api/appointments', (req,res)=>{
  const body = req.body
  if(!body.date) return res.status(400).json({error:'date required'})
  const id = 'a'+Date.now()
  const appt = {id,serviceId:body.serviceId||null,comboId:body.comboId||null,date:body.date,note:body.note||'',status:'confirmado'}
  ds.pushAppointment(appt)
  return res.status(201).json(appt)
})

app.post('/api/payments/:id', (req,res)=>{
  const id = req.params.id
  const updated = ds.updateAppointment(id,{status:'pago'})
  if(!updated) return res.status(404).json({error:'not found'})
  return res.json(updated)
})

app.post('/api/reminder', (req,res)=>{
  // stub: em produção integrar SMS/WhatsApp
  console.log('reminder requested',req.body)
  return res.json({ok:true})
})

app.post('/api/whatsapp', (req,res)=>{
  // stub: em produção usar Twilio/WhatsApp Business API
  console.log('whatsapp send',req.body)
  return res.json({ok:true})
})

app.get('/api/data', (req,res)=>{res.json(ds.read())})

const PORT = process.env.PORT || 3000
app.listen(PORT, ()=>console.log('Server running on port',PORT))
