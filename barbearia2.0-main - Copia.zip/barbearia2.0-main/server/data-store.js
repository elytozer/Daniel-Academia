const fs = require('fs')
const path = require('path')
const FILE = path.join(__dirname,'data.json')

function read(){
  try{const raw = fs.readFileSync(FILE,'utf8');return JSON.parse(raw)}catch(e){return {services:[],combos:[],appointments:[],favTimes:[],profile:{},feedbacks:[],promos:[]}}
}

function write(data){fs.writeFileSync(FILE,JSON.stringify(data,null,2),'utf8')}

function get(key){const d=read();return d[key]}
function set(key,val){const d=read();d[key]=val;write(d);return val}

function pushAppointment(appt){const d=read();d.appointments.unshift(appt);write(d);return appt}

function updateAppointment(id,patch){const d=read();const idx=d.appointments.findIndex(a=>a.id===id);if(idx===-1) return null;d.appointments[idx]=Object.assign({},d.appointments[idx],patch);write(d);return d.appointments[idx]}

module.exports = {read,write,get,set,pushAppointment,updateAppointment}
